# Interview Case Study - HR Analytics in Power BI

This repository is the accompanying repository for the Power BI interview case study live training. You can find the data in the `Datasets` folder, and the metadata sheet that accompanies the data in the root folder.
